"use client";

import { useState } from "react";
import { useAccount, useReadContract, useWriteContract } from "wagmi";
import { ConnectButton } from "@rainbow-me/rainbowkit";
import { GLIK_ADDRESS, GLIK_ABI, OWNER_ADDRESS } from "@/lib/contracts";
import Link from "next/link";
import { parseEther, formatEther } from "viem";

export default function AdminPage() {
  const { address, isConnected } = useAccount();
  const isOwner = address?.toLowerCase() === OWNER_ADDRESS.toLowerCase();

  const [newFee, setNewFee] = useState("");
  const [reserveTo, setReserveTo] = useState("");
  const [reserveQty, setReserveQty] = useState("1");
  const [status, setStatus] = useState("");

  const { data: publicMinted } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "publicMinted",
  });

  const { data: ethFee } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "ethFee",
  });

  const { data: totalSupply } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "totalSupply",
  });

  const { data: paused } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "paused",
  });

  const { writeContractAsync } = useWriteContract();

  const run = async (fn: () => Promise<any>, successMsg: string) => {
    setStatus("Pending...");
    try {
      await fn();
      setStatus(successMsg);
    } catch (err: any) {
      setStatus(err?.shortMessage || err?.message || "Failed");
    }
  };

  if (!isConnected) {
    return (
      <main className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl mb-6">Admin Panel</h1>
          <ConnectButton />
        </div>
      </main>
    );
  }

  if (!isOwner) {
    return (
      <main className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl text-red-400 mb-4">Access Denied</h1>
          <p className="text-zinc-500">Only the owner wallet can access this page.</p>
          <Link href="/" className="text-yellow-400 mt-4 inline-block">← Back</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-2xl mx-auto px-6 py-12">
        <Link href="/" className="text-zinc-500 hover:text-yellow-400 text-sm mb-8 inline-block">
          ← Back
        </Link>

        <h1 className="text-3xl font-bold mb-8 text-yellow-400">GLIK Admin Panel</h1>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500">Public Minted</p>
            <p className="text-xl font-bold">{publicMinted?.toString() ?? "—"} / 7000</p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500">Total Supply</p>
            <p className="text-xl font-bold">{totalSupply?.toString() ?? "—"} / 7500</p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500">ETH Fee</p>
            <p className="text-xl font-bold">
              {ethFee ? formatEther(ethFee as bigint) : "—"} ETH
            </p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500">Status</p>
            <p className={`text-xl font-bold ${paused ? "text-red-400" : "text-green-400"}`}>
              {paused ? "Paused" : "Live"}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-6">
          {/* Pause / Unpause */}
          <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
            <h2 className="font-semibold mb-3">Mint Status</h2>
            <div className="flex gap-3">
              <button
                onClick={() =>
                  run(
                    () =>
                      writeContractAsync({
                        address: GLIK_ADDRESS,
                        abi: [
                          { name: "pause", type: "function", inputs: [], outputs: [], stateMutability: "nonpayable" },
                        ],
                        functionName: "pause",
                      }),
                    "Minting paused"
                  )
                }
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-sm font-medium"
              >
                Pause Minting
              </button>
              <button
                onClick={() =>
                  run(
                    () =>
                      writeContractAsync({
                        address: GLIK_ADDRESS,
                        abi: [
                          { name: "unpause", type: "function", inputs: [], outputs: [], stateMutability: "nonpayable" },
                        ],
                        functionName: "unpause",
                      }),
                    "Minting unpaused"
                  )
                }
                className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-sm font-medium"
              >
                Unpause Minting
              </button>
            </div>
          </div>

          {/* Change ETH Fee */}
          <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
            <h2 className="font-semibold mb-3">Update ETH Fee</h2>
            <div className="flex gap-3">
              <input
                type="text"
                placeholder="0.00041"
                value={newFee}
                onChange={(e) => setNewFee(e.target.value)}
                className="flex-1 px-4 py-2 rounded-lg bg-black border border-zinc-700 outline-none"
              />
              <button
                onClick={() =>
                  run(
                    () =>
                      writeContractAsync({
                        address: GLIK_ADDRESS,
                        abi: [
                          {
                            name: "setEthFee",
                            type: "function",
                            inputs: [{ name: "newFee", type: "uint256" }],
                            outputs: [],
                            stateMutability: "nonpayable",
                          },
                        ],
                        functionName: "setEthFee",
                        args: [parseEther(newFee || "0")],
                      }),
                    "ETH fee updated"
                  )
                }
                className="px-4 py-2 rounded-lg bg-yellow-500 text-black font-medium text-sm"
              >
                Update
              </button>
            </div>
            <p className="text-xs text-zinc-500 mt-2">Enter value in ETH (e.g. 0.00041)</p>
          </div>

          {/* Mint Reserved */}
          <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
            <h2 className="font-semibold mb-3">Mint Reserved (max 500)</h2>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Recipient address 0x..."
                value={reserveTo}
                onChange={(e) => setReserveTo(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-black border border-zinc-700 outline-none"
              />
              <div className="flex gap-3">
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={reserveQty}
                  onChange={(e) => setReserveQty(e.target.value)}
                  className="w-24 px-4 py-2 rounded-lg bg-black border border-zinc-700 outline-none"
                />
                <button
                  onClick={() =>
                    run(
                      () =>
                        writeContractAsync({
                          address: GLIK_ADDRESS,
                          abi: [
                            {
                              name: "mintReserved",
                              type: "function",
                              inputs: [
                                { name: "to", type: "address" },
                                { name: "quantity", type: "uint256" },
                              ],
                              outputs: [],
                              stateMutability: "nonpayable",
                            },
                          ],
                          functionName: "mintReserved",
                          args: [reserveTo as `0x${string}`, BigInt(reserveQty || "1")],
                        }),
                      `Minted ${reserveQty} reserved NFTs`
                    )
                  }
                  className="px-4 py-2 rounded-lg bg-yellow-500 text-black font-medium text-sm"
                >
                  Mint Reserved
                </button>
              </div>
            </div>
          </div>
        </div>

        {status && (
          <p className="mt-6 text-center text-sm text-zinc-400">{status}</p>
        )}
      </div>
    </main>
  );
}
