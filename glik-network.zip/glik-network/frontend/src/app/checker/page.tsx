"use client";

import { useState } from "react";
import { useAccount, useReadContract } from "wagmi";
import { ConnectButton } from "@rainbow-me/rainbowkit";
import { GLIK_ADDRESS, GLIK_ABI } from "@/lib/contracts";
import Link from "next/link";
import { isAddress } from "viem";

export default function CheckerPage() {
  const { address, isConnected } = useAccount();
  const [inputAddress, setInputAddress] = useState("");
  const [checkAddress, setCheckAddress] = useState<`0x${string}` | undefined>();

  const target = checkAddress || (isConnected ? address : undefined);

  const { data: isWhitelisted, isLoading, refetch } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "isWhitelisted",
    args: target ? [target] : undefined,
    query: { enabled: !!target },
  });

  const { data: balance } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "balanceOf",
    args: target ? [target] : undefined,
    query: { enabled: !!target },
  });

  const handleCheck = () => {
    if (isAddress(inputAddress)) {
      setCheckAddress(inputAddress as `0x${string}`);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-lg mx-auto px-6 py-16">
        <Link href="/" className="text-zinc-500 hover:text-yellow-400 text-sm mb-8 inline-block">
          ← Back
        </Link>

        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">
          Whitelist Checker
        </h1>
        <p className="text-zinc-400 mb-10">
          Check if a wallet holds a GLIK NFT and is eligible for the upcoming testnet.
        </p>

        {/* Connected wallet quick check */}
        <div className="mb-8">
          {!isConnected ? (
            <div className="flex justify-center mb-6">
              <ConnectButton />
            </div>
          ) : (
            <button
              onClick={() => {
                setCheckAddress(undefined);
                setInputAddress("");
                refetch();
              }}
              className="w-full py-3 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-yellow-500/50 transition mb-4"
            >
              Check my connected wallet
            </button>
          )}
        </div>

        {/* Manual address input */}
        <div className="flex gap-2 mb-8">
          <input
            type="text"
            placeholder="0x... wallet address"
            value={inputAddress}
            onChange={(e) => setInputAddress(e.target.value)}
            className="flex-1 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700 focus:border-yellow-500 outline-none text-sm"
          />
          <button
            onClick={handleCheck}
            className="px-6 py-3 rounded-xl bg-yellow-500 text-black font-semibold hover:bg-yellow-400 transition"
          >
            Check
          </button>
        </div>

        {/* Result */}
        {target && (
          <div className="rounded-2xl border p-8 text-center">
            {isLoading ? (
              <p className="text-zinc-400">Checking...</p>
            ) : isWhitelisted ? (
              <div className="border-green-500/40 bg-green-500/10 rounded-2xl p-6">
                <div className="text-5xl mb-4">✅</div>
                <h2 className="text-2xl font-bold text-green-400 mb-2">Whitelisted</h2>
                <p className="text-zinc-400 text-sm mb-2">
                  This wallet holds {balance?.toString() || "1"} GLIK NFT
                </p>
                <p className="text-xs text-zinc-500 break-all">{target}</p>
              </div>
            ) : (
              <div className="border-red-500/40 bg-red-500/10 rounded-2xl p-6">
                <div className="text-5xl mb-4">❌</div>
                <h2 className="text-2xl font-bold text-red-400 mb-2">Not Whitelisted</h2>
                <p className="text-zinc-400 text-sm mb-4">
                  This wallet does not hold a GLIK NFT
                </p>
                <Link
                  href="/mint"
                  className="inline-block px-6 py-2 rounded-lg bg-yellow-500 text-black font-medium text-sm hover:bg-yellow-400"
                >
                  Mint GLIK NFT
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
