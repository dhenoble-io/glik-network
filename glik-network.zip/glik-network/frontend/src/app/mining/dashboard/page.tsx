"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAccount, useConnect } from "wagmi";

const API = process.env.NEXT_PUBLIC_MINING_API || "http://localhost:4000";

interface User {
  id: string;
  email: string;
  walletAddress?: string;
  referralCode: string;
  points: string;
  energy: number;
  maxEnergy: number;
  level: number;
  totalReferrals: number;
  referralPoints: string;
}

export default function MiningDashboard() {
  const router = useRouter();
  const { address, isConnected } = useAccount();
  const [user, setUser] = useState<User | null>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [mining, setMining] = useState(false);
  const [msg, setMsg] = useState("");

  const token = typeof window !== "undefined" ? localStorage.getItem("glik_token") : null;

  const fetchMe = async () => {
    if (!token) {
      router.push("/mining/login");
      return;
    }
    try {
      const res = await fetch(`${API}/api/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Unauthorized");
      const data = await res.json();
      setUser(data);
    } catch {
      localStorage.removeItem("glik_token");
      router.push("/mining/login");
    } finally {
      setLoading(false);
    }
  };

  const fetchLeaderboard = async () => {
    const res = await fetch(`${API}/api/leaderboard`);
    const data = await res.json();
    setLeaderboard(data);
  };

  useEffect(() => {
    fetchMe();
    fetchLeaderboard();
  }, []);

  const handleMine = async () => {
    if (!token || mining) return;
    setMining(true);
    setMsg("");
    try {
      const res = await fetch(`${API}/api/mine`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ taps: 5 }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Mine failed");
      setUser((prev) =>
        prev
          ? { ...prev, points: data.points, energy: data.energy }
          : prev
      );
      setMsg(`+5 points!`);
    } catch (err: any) {
      setMsg(err.message);
    } finally {
      setMining(false);
    }
  };

  const linkWallet = async () => {
    if (!address || !token) return;
    try {
      const res = await fetch(`${API}/api/wallet/link`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ walletAddress: address }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setUser((prev) => (prev ? { ...prev, walletAddress: data.walletAddress } : prev));
      setMsg("Wallet linked successfully");
    } catch (err: any) {
      setMsg(err.message);
    }
  };

  const logout = () => {
    localStorage.removeItem("glik_token");
    localStorage.removeItem("glik_user");
    router.push("/mining/login");
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-black text-white flex items-center justify-center">
        Loading...
      </main>
    );
  }

  if (!user) return null;

  const referralLink =
    typeof window !== "undefined"
      ? `${window.location.origin}/mining/register?ref=${user.referralCode}`
      : "";

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto px-6 py-10">
        {/* Header */}
        <div className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-2xl font-bold text-yellow-400">GLIK Mining</h1>
            <p className="text-zinc-500 text-sm">{user.email}</p>
          </div>
          <button onClick={logout} className="text-sm text-zinc-500 hover:text-white">
            Logout
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
            <p className="text-3xl font-bold text-yellow-400">{user.points}</p>
            <p className="text-xs text-zinc-500 mt-1">POINTS</p>
          </div>
          <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
            <p className="text-3xl font-bold">{user.energy}/{user.maxEnergy}</p>
            <p className="text-xs text-zinc-500 mt-1">ENERGY</p>
          </div>
          <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
            <p className="text-3xl font-bold">{user.level}</p>
            <p className="text-xs text-zinc-500 mt-1">LEVEL</p>
          </div>
          <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
            <p className="text-3xl font-bold">{user.totalReferrals}</p>
            <p className="text-xs text-zinc-500 mt-1">REFERRALS</p>
          </div>
        </div>

        {/* Mine Button */}
        <div className="text-center mb-12">
          <button
            onClick={handleMine}
            disabled={mining || user.energy < 5}
            className="w-48 h-48 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 text-black font-bold text-2xl shadow-2xl shadow-yellow-500/30 hover:scale-105 active:scale-95 transition disabled:opacity-40"
          >
            {mining ? "..." : "MINE"}
          </button>
          {msg && <p className="mt-4 text-sm text-zinc-400">{msg}</p>}
        </div>

        {/* Wallet */}
        <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 mb-8">
          <h2 className="font-semibold mb-3">Wallet</h2>
          {user.walletAddress ? (
            <p className="text-sm text-green-400 break-all">{user.walletAddress}</p>
          ) : (
            <div>
              <p className="text-sm text-zinc-500 mb-3">Link your EVM wallet for future claims</p>
              {isConnected ? (
                <button
                  onClick={linkWallet}
                  className="px-4 py-2 rounded-lg bg-yellow-500 text-black text-sm font-medium"
                >
                  Link {address?.slice(0, 6)}...{address?.slice(-4)}
                </button>
              ) : (
                <p className="text-xs text-zinc-600">Connect wallet first (use header button)</p>
              )}
            </div>
          )}
        </div>

        {/* Referral */}
        <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 mb-8">
          <h2 className="font-semibold mb-3">Your Referral Link</h2>
          <p className="text-xs text-zinc-500 mb-2">Share this link. You earn 500 points per referral.</p>
          <div className="flex gap-2">
            <input
              readOnly
              value={referralLink}
              className="flex-1 px-3 py-2 rounded-lg bg-black border border-zinc-700 text-sm"
            />
            <button
              onClick={() => {
                navigator.clipboard.writeText(referralLink);
                setMsg("Link copied!");
              }}
              className="px-4 py-2 rounded-lg bg-zinc-700 text-sm hover:bg-zinc-600"
            >
              Copy
            </button>
          </div>
          <p className="text-xs text-zinc-600 mt-2">Code: {user.referralCode}</p>
        </div>

        {/* Leaderboard */}
        <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800">
          <h2 className="font-semibold mb-4">Leaderboard</h2>
          <div className="space-y-2">
            {leaderboard.slice(0, 10).map((u) => (
              <div
                key={u.rank}
                className="flex justify-between items-center py-2 border-b border-zinc-800 last:border-0"
              >
                <span className="text-sm">
                  <span className="text-zinc-500 mr-3">#{u.rank}</span>
                  {u.name}
                </span>
                <span className="text-yellow-400 text-sm font-medium">{u.points}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="text-center mt-10">
          <Link href="/" className="text-zinc-600 text-sm hover:text-zinc-400">
            ← Back to GLIK Network
          </Link>
        </p>
      </div>
    </main>
  );
}
