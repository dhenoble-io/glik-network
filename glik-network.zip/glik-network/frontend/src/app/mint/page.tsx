"use client";

import { useState, useEffect } from "react";
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from "wagmi";
import { ConnectButton } from "@rainbow-me/rainbowkit";
import { GLIK_ADDRESS, GLIK_ABI, USDT_ADDRESS, USDT_ABI, USDT_PRICE } from "@/lib/contracts";
import Link from "next/link";

export default function MintPage() {
  const { address, isConnected } = useAccount();
  const [step, setStep] = useState<"idle" | "approving" | "minting" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  // Reads
  const { data: hasMinted } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "hasMinted",
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  const { data: remaining } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "remainingPublic",
  });

  const { data: ethFee } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "ethFee",
  });

  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: USDT_ADDRESS,
    abi: USDT_ABI,
    functionName: "allowance",
    args: address ? [address, GLIK_ADDRESS] : undefined,
    query: { enabled: !!address },
  });

  const { writeContractAsync } = useWriteContract();

  const needsApproval = allowance !== undefined && allowance < USDT_PRICE;

  const handleMint = async () => {
    if (!address || !ethFee) return;
    setErrorMsg("");
    try {
      if (needsApproval) {
        setStep("approving");
        const approveTx = await writeContractAsync({
          address: USDT_ADDRESS,
          abi: USDT_ABI,
          functionName: "approve",
          args: [GLIK_ADDRESS, USDT_PRICE],
        });
        // Wait is handled by the hook pattern in real apps; simplified here
        await new Promise((r) => setTimeout(r, 3000));
        await refetchAllowance();
      }

      setStep("minting");
      await writeContractAsync({
        address: GLIK_ADDRESS,
        abi: GLIK_ABI,
        functionName: "mint",
        value: ethFee as bigint,
      });

      setStep("success");
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.shortMessage || err?.message || "Transaction failed");
      setStep("error");
    }
  };

  const alreadyMinted = hasMinted === true;
  const soldOut = remaining !== undefined && remaining === 0n;

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-lg mx-auto px-6 py-16">
        <Link href="/" className="text-zinc-500 hover:text-yellow-400 text-sm mb-8 inline-block">
          ← Back
        </Link>

        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">
          Mint GLIK OG
        </h1>
        <p className="text-zinc-400 mb-10">Secure your whitelist spot for the upcoming testnet.</p>

        {/* Price Card */}
        <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-8 mb-8 text-center">
          <p className="text-zinc-500 text-sm uppercase tracking-wider mb-2">Mint Price</p>
          <p className="text-5xl font-bold text-yellow-400 mb-1">4 USDT</p>
          <p className="text-zinc-600 text-xs">1 NFT per wallet</p>
        </div>

        {/* Stats */}
        <div className="flex justify-between text-sm text-zinc-500 mb-8 px-2">
          <span>Remaining: {remaining !== undefined ? remaining.toString() : "—"} / 7000</span>
          <span>{alreadyMinted ? "You already minted" : "Available"}</span>
        </div>

        {/* Connect / Mint */}
        {!isConnected ? (
          <div className="flex justify-center">
            <ConnectButton />
          </div>
        ) : alreadyMinted ? (
          <div className="text-center p-6 rounded-xl bg-green-500/10 border border-green-500/30">
            <p className="text-green-400 font-medium">You already own a GLIK NFT</p>
            <Link href="/checker" className="text-sm text-yellow-400 mt-2 inline-block">
              Check whitelist status →
            </Link>
          </div>
        ) : soldOut ? (
          <div className="text-center p-6 rounded-xl bg-red-500/10 border border-red-500/30">
            <p className="text-red-400 font-medium">Public supply sold out</p>
          </div>
        ) : (
          <button
            onClick={handleMint}
            disabled={step === "approving" || step === "minting"}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold text-lg hover:opacity-90 disabled:opacity-50 transition"
          >
            {step === "approving" && "Approving USDT..."}
            {step === "minting" && "Minting..."}
            {step === "success" && "Success! 🎉"}
            {(step === "idle" || step === "error") && "Mint for 4 USDT"}
          </button>
        )}

        {errorMsg && (
          <p className="mt-4 text-red-400 text-sm text-center">{errorMsg}</p>
        )}

        {step === "success" && (
          <div className="mt-6 text-center">
            <Link href="/checker" className="text-yellow-400 hover:underline">
              Go to Whitelist Checker →
            </Link>
          </div>
        )}

        <p className="mt-10 text-center text-xs text-zinc-600">
          By minting you agree to the terms of GLIK Network.
        </p>
      </div>
    </main>
  );
}
