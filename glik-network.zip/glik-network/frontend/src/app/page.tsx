"use client";

import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black text-white">
      <div className="max-w-5xl mx-auto px-6 py-20">
        {/* Hero */}
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4">
            <span className="bg-gradient-to-r from-yellow-300 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
              GLIK NETWORK
            </span>
          </h1>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Official OG Pass. Mint your GLIK NFT to secure whitelist access for the upcoming testnet and future rewards.
          </p>
        </div>

        {/* NFT Preview */}
        <div className="flex justify-center mb-16">
          <div className="relative w-72 h-72 rounded-full bg-gradient-to-br from-yellow-400/20 to-amber-700/20 border border-yellow-500/30 flex items-center justify-center shadow-2xl shadow-yellow-500/10">
            <div className="text-center">
              <div className="text-6xl mb-2">🪙</div>
              <p className="text-yellow-400 font-semibold text-lg">GLIK OG</p>
              <p className="text-zinc-500 text-sm">Limited Edition</p>
            </div>
          </div>
        </div>

        {/* Action Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Link
            href="/mint"
            className="group p-8 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-yellow-500/50 transition-all hover:scale-[1.02]"
          >
            <h2 className="text-2xl font-bold mb-2 group-hover:text-yellow-400 transition-colors">
              Mint NFT
            </h2>
            <p className="text-zinc-400 text-sm mb-4">
              Mint for 4 USDT. Only 7000 available. 1 per wallet.
            </p>
            <span className="text-yellow-500 text-sm font-medium">Mint Now →</span>
          </Link>

          <Link
            href="/checker"
            className="group p-8 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-yellow-500/50 transition-all hover:scale-[1.02]"
          >
            <h2 className="text-2xl font-bold mb-2 group-hover:text-yellow-400 transition-colors">
              Whitelist Checker
            </h2>
            <p className="text-zinc-400 text-sm mb-4">
              Check if your wallet holds a GLIK NFT and is eligible for testnet.
            </p>
            <span className="text-yellow-500 text-sm font-medium">Check Status →</span>
          </Link>

          <Link
            href="/testnet"
            className="group p-8 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-yellow-500/50 transition-all hover:scale-[1.02]"
          >
            <h2 className="text-2xl font-bold mb-2 group-hover:text-yellow-400 transition-colors">
              Testnet
            </h2>
            <p className="text-zinc-400 text-sm mb-4">
              Upcoming testnet access for GLIK NFT holders only.
            </p>
            <span className="text-yellow-500 text-sm font-medium">View Details →</span>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-xl bg-zinc-900/50">
            <p className="text-2xl font-bold text-yellow-400">7500</p>
            <p className="text-xs text-zinc-500 uppercase tracking-wider">Max Supply</p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900/50">
            <p className="text-2xl font-bold text-yellow-400">7000</p>
            <p className="text-xs text-zinc-500 uppercase tracking-wider">Public Mint</p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900/50">
            <p className="text-2xl font-bold text-yellow-400">4 USDT</p>
            <p className="text-xs text-zinc-500 uppercase tracking-wider">Mint Price</p>
          </div>
          <div className="p-4 rounded-xl bg-zinc-900/50">
            <p className="text-2xl font-bold text-yellow-400">1 / Wallet</p>
            <p className="text-xs text-zinc-500 uppercase tracking-wider">Limit</p>
          </div>
        </div>
      </div>
    </main>
  );
}
