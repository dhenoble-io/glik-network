"use client";

import { useAccount, useReadContract } from "wagmi";
import { ConnectButton } from "@rainbow-me/rainbowkit";
import { GLIK_ADDRESS, GLIK_ABI } from "@/lib/contracts";
import Link from "next/link";

export default function TestnetPage() {
  const { address, isConnected } = useAccount();

  const { data: isWhitelisted } = useReadContract({
    address: GLIK_ADDRESS,
    abi: GLIK_ABI,
    functionName: "isWhitelisted",
    args: address ? [address] : undefined,
    query: { enabled: !!address },
  });

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-2xl mx-auto px-6 py-16">
        <Link href="/" className="text-zinc-500 hover:text-yellow-400 text-sm mb-8 inline-block">
          ← Back
        </Link>

        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-300 to-amber-500 bg-clip-text text-transparent">
          GLIK Testnet
        </h1>

        <div className="rounded-2xl bg-zinc-900/80 border border-zinc-800 p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <span className="px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-xs font-semibold uppercase tracking-wider">
              Coming Soon
            </span>
          </div>

          <h2 className="text-2xl font-bold mb-4">Upcoming Testnet Access</h2>
          <p className="text-zinc-400 leading-relaxed mb-6">
            The GLIK Network testnet is currently under development.  
            Only wallets that hold a <strong className="text-yellow-400">GLIK OG NFT</strong> will be able to participate when it goes live.
          </p>

          <ul className="space-y-3 text-zinc-400 text-sm mb-8">
            <li className="flex items-start gap-2">
              <span className="text-yellow-500 mt-0.5">•</span>
              Whitelist is automatically granted to all GLIK NFT holders
            </li>
            <li className="flex items-start gap-2">
              <span className="text-yellow-500 mt-0.5">•</span>
              No additional tasks required at this stage
            </li>
            <li className="flex items-start gap-2">
              <span className="text-yellow-500 mt-0.5">•</span>
              Follow official channels for launch announcements
            </li>
          </ul>

          {/* Status for connected wallet */}
          <div className="border-t border-zinc-800 pt-6">
            {!isConnected ? (
              <div className="text-center">
                <p className="text-zinc-500 text-sm mb-4">Connect your wallet to check eligibility</p>
                <ConnectButton />
              </div>
            ) : isWhitelisted ? (
              <div className="text-center p-4 rounded-xl bg-green-500/10 border border-green-500/30">
                <p className="text-green-400 font-medium">✅ Your wallet is whitelisted</p>
                <p className="text-zinc-500 text-xs mt-1">You will have access when testnet launches</p>
              </div>
            ) : (
              <div className="text-center p-4 rounded-xl bg-red-500/10 border border-red-500/30">
                <p className="text-red-400 font-medium">❌ Not whitelisted</p>
                <p className="text-zinc-500 text-xs mt-1 mb-3">You need a GLIK NFT to participate</p>
                <Link
                  href="/mint"
                  className="inline-block px-5 py-2 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400"
                >
                  Mint GLIK NFT
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
