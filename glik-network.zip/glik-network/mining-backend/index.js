import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
import { randomBytes } from "crypto";

dotenv.config();
const app = express();
const prisma = new PrismaClient();

app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || "change-me-in-production";

// Helper: generate referral code
function generateReferralCode() {
  return randomBytes(4).toString("hex").toUpperCase();
}

// Auth middleware
function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  try {
    const token = header.slice(7);
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.userId;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
}

// ========== AUTH ==========

// Register
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, referralCode } = req.body;
    if (!email || !password || password.length < 6) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(400).json({ error: "Email already registered" });

    let referredById = null;
    if (referralCode) {
      const referrer = await prisma.user.findUnique({ where: { referralCode } });
      if (referrer) referredById = referrer.id;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        referralCode: generateReferralCode(),
        referredById,
      },
    });

    // Reward referrer
    if (referredById) {
      await prisma.user.update({
        where: { id: referredById },
        data: {
          totalReferrals: { increment: 1 },
          points: { increment: 500 },
          referralPoints: { increment: 500 },
        },
      });
      // Small bonus for new user
      await prisma.user.update({
        where: { id: user.id },
        data: { points: { increment: 200 } },
      });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "30d" });
    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        referralCode: user.referralCode,
        points: user.points.toString(),
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// Login
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { lastActiveAt: new Date() },
    });

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "30d" });
    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        walletAddress: user.walletAddress,
        referralCode: user.referralCode,
        points: user.points.toString(),
        energy: user.energy,
        totalReferrals: user.totalReferrals,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ========== USER ==========

// Get me
app.get("/api/me", auth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: "User not found" });

  res.json({
    id: user.id,
    email: user.email,
    walletAddress: user.walletAddress,
    referralCode: user.referralCode,
    points: user.points.toString(),
    energy: user.energy,
    maxEnergy: user.maxEnergy,
    level: user.level,
    totalReferrals: user.totalReferrals,
    referralPoints: user.referralPoints.toString(),
  });
});

// Link wallet
app.post("/api/wallet/link", auth, async (req, res) => {
  const { walletAddress } = req.body;
  if (!walletAddress || !/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
    return res.status(400).json({ error: "Invalid wallet address" });
  }

  // Check if wallet already linked to another account
  const existing = await prisma.user.findUnique({ where: { walletAddress } });
  if (existing && existing.id !== req.userId) {
    return res.status(400).json({ error: "Wallet already linked to another account" });
  }

  const user = await prisma.user.update({
    where: { id: req.userId },
    data: { walletAddress },
  });

  res.json({ walletAddress: user.walletAddress });
});

// ========== MINING ==========

app.post("/api/mine", auth, async (req, res) => {
  const taps = Math.min(Number(req.body.taps) || 1, 20);

  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user || user.isBanned) return res.status(403).json({ error: "Banned" });

  if (user.energy < taps) {
    return res.status(400).json({ error: "Not enough energy" });
  }

  const updated = await prisma.user.update({
    where: { id: req.userId },
    data: {
      energy: { decrement: taps },
      points: { increment: taps },
      lastMineAt: new Date(),
      lastActiveAt: new Date(),
    },
  });

  await prisma.activityLog.create({
    data: {
      userId: req.userId,
      type: "mine",
      amount: BigInt(taps),
    },
  });

  res.json({
    points: updated.points.toString(),
    energy: updated.energy,
  });
});

// ========== LEADERBOARD ==========

app.get("/api/leaderboard", async (req, res) => {
  const top = await prisma.user.findMany({
    where: { isBanned: false },
    orderBy: { points: "desc" },
    take: 50,
    select: {
      id: true,
      username: true,
      walletAddress: true,
      points: true,
    },
  });

  res.json(
    top.map((u, i) => ({
      rank: i + 1,
      name: u.username || (u.walletAddress ? `${u.walletAddress.slice(0, 6)}...${u.walletAddress.slice(-4)}` : "Anonymous"),
      points: u.points.toString(),
    }))
  );
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`GLIK Mining Backend running on :${PORT}`));
