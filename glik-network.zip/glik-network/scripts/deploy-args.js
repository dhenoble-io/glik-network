// Constructor arguments for GLIK.sol
// Use with Hardhat or Foundry

module.exports = [
  "0xDf051B410773d7510B58031dEf47fbc2922858C3", // initialOwner
  "ipfs://PLACEHOLDER_CID/",                     // baseURI (update after uploading metadata)
  "410000000000000"                              // 0.00041 ether in wei
];
